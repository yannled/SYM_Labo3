package ch.heigvd.sym.template;

/**
 * Autheur: Yann Lederrey, Joel Schar, Yohann Meyer
 */

public interface nfcMethod {
    public void doAfterNfcEnable();
}
